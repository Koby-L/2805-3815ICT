import pygame
from mk1settings import *
import random
class Environment():
    #This is the grid that the game is built upon
    def setUpGrid(self):

        #Large 2D grid that the game is built upon. HorizontalNum and VerticalNum are the rows and columns in the grid.
        grid = [ [ 0 ] * HorizontalNum for n in range(VerticalNum)]
        

        #Just setting the starting location of pacman.
        grid[7][7]=3

        #Set the walls, roof and floor to 1.
        for col in range(VerticalNum):
            grid[col][0]=1
            grid[col][HorizontalNum-1]=1
        
        for row in range(HorizontalNum):
            grid[0][row]=1
            grid[VerticalNum-1][row]=1



        #Get our random openings, one on left wall one on right wall.
        Opening = random.randint(1,VerticalNum-1)
        Opening2 = random.randint(1,VerticalNum-1)

        
        #These are the random tunnels, I haven't implemented anything for them yet
        grid[Opening][0]=2
        grid[Opening2][HorizontalNum-1]=2
        return grid
